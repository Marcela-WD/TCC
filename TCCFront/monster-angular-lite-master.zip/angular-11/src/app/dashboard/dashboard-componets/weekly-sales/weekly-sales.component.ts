import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weekly-sales',
  templateUrl: './weekly-sales.component.html',
  styleUrls: ['./weekly-sales.component.css']
})
export class WeeklySalesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
